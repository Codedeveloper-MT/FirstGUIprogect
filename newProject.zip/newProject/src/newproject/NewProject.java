
package newproject;

public class NewProject {

    public static void main(String[] args) {
       new UserIdentity();
    }
    
}
