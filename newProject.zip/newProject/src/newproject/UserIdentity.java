package newproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class UserIdentity extends JFrame {
    
    JPanel panel;
    JLabel lblName;
    JLabel lblSurname;
    JLabel lblTitle;
    JTextField tfName;
    JTextField tfSurname;

    public UserIdentity() {
        // Initialize components
        panel = new JPanel();
        lblTitle = new JLabel("User Identity");
        lblName = new JLabel("Name:");
        lblSurname = new JLabel("Surname:");
        tfName = new JTextField(20); // 20 columns wide
        tfSurname = new JTextField(20);

        // Set layout
        panel.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 20)); // Left aligned with gaps

        // Customize components
        lblTitle.setFont(new Font("Serif", Font.BOLD, 24));
        lblTitle.setForeground(Color.BLUE);
        lblTitle.setHorizontalAlignment(JLabel.CENTER);

        lblName.setFont(new Font("SansSerif", Font.PLAIN, 18));
        lblSurname.setFont(new Font("SansSerif", Font.PLAIN, 18));

        tfName.setPreferredSize(new Dimension(200, 30)); // Set preferred size for text fields
        tfSurname.setPreferredSize(new Dimension(200, 30));
        
        tfName.setFont(new Font("SansSerif", Font.PLAIN, 16));
        tfSurname.setFont(new Font("SansSerif", Font.PLAIN, 16));

        // Set background color for the panel
        panel.setBackground(Color.ORANGE);

        // Add borders for padding
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Add padding around the panel

        // Add components to panel
        panel.add(lblTitle);
        panel.add(lblName);
        panel.add(tfName);
        System.out.println("\n");
        panel.add(lblSurname);
        panel.add(tfSurname);

        // Set title label to span across all columns
        lblTitle.setPreferredSize(new Dimension(460, 50)); // Adjust width and height as needed
        lblTitle.setHorizontalAlignment(JLabel.CENTER);

        // Add panel to the frame
        add(panel);

        // Set frame properties
        this.setTitle("User Identity");
        this.setSize(500, 400); // Adjust the size as needed
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

   
}
